import { Component} from '@angular/core';
@Component({
	selector: 'fontawesome',
	templateUrl: './fontawesome.component.html' 
})
export class fontawesomeComponent {
	
}