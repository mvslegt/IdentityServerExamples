import { Component, OnInit  } from '@angular/core';

@Component({
  selector: 'ma-rightsidebar',
  templateUrl: './rightsidebar.component.html'
})
export class RightSidebarComponent {
	constructor() {}
	ngOnInit() {
		
	}
}
